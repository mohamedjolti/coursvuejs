<template>
  <div>
      <h1>{{componentName}}</h1>
  </div>
</template>

<script>
export default {
components:{},
   data(){
       return {
           componentName:"header"
       }
   }
}
</script>

<style>

</style>